# Final research snapshot — October 4, 2026

This is a reproducible research archive, **not a verified release, deployment, official competition score, or legal certification**. The recorded full readiness gate reports all five cases as partial.

The final Store has 678 rules, 86 sources and 500 properties. It preserves the exact final source bundle, provider drafts/reviews/repairs, cache entries, run manifests and cumulative budget ledger. There were 34 reconciled provider requests with a recorded upper cost estimate of $3.55834050 against the same $5 allowance. Packaging and offline verification made no new provider calls.

## Contents

- `store/`: exact final Store, including `provider_outputs/`, `runs/`, `extraction_cache/`, and `change_case_source_bundle/`.
- `records/`: unchanged final audit, readiness, replay and test receipts. Their original absolute paths remain historical metadata; local counterparts are identified in `MANIFEST.json`.
- `research/municipal-followup/`: retained municipal follow-up evidence and unresolved acquisition findings.
- `runtime/`: the exact application files and locked dependencies required to reproduce the recorded final package. This is a replay snapshot, not a separate production installation.
- `requests/A0001.json`: the exact recorded A0001 request for 2026-10-01, with every analysis bound set to one.
- `tools/`: offline verification/rebuild tools. `tools/original/` retains the original research helpers unchanged for provenance; historical comparison helpers require earlier Stores, and extraction helpers are **not** part of offline replay.

Earlier full Store copies and the 43 MB final/34 MB hosted evidence packages are excluded to avoid duplication. The final package can be reconstructed byte-for-byte from this archive. A separate ignored local session backup preserves the full investigation. Historical before/after reports are retained, but regenerating those comparisons requires that separate historical backup.

## Verify archived bytes

From this extracted directory:

```sh
python3 tools/verify_archive.py
```

The manifest hashes every payload file except itself. Verify the ZIP against its published SHA-256 as well; hashes detect changes and do not independently authenticate source authority.

## Rebuild and replay the evidence package without a provider

Exact replay requires **Python 3.12.14** and the recorded dependencies. Use an existing matching environment or create one outside this archive:

```sh
python3.12 -m venv ../tenent-replay-venv
../tenent-replay-venv/bin/python -m pip install -r runtime/requirements.lock
../tenent-replay-venv/bin/python tools/rebuild_evidence_package.py \
  --output ../final-evidence-package.json \
  --receipt ../replay-receipt.json
```

Installing dependencies may require package-network access. The rebuild itself blocks HTTP transport, loads no `.env`, makes no provider calls, verifies the archive before/after, checks the recorded package digest and file digest, and replays the newly generated output through the existing package builder. Use new output filenames; it will not overwrite an existing package. The result must remain partial and non-exhaustive, with the original one-field/one-evaluation bounds and unknown conclusions.

## Re-run the full readiness gate

```sh
PYTHON_DOTENV_DISABLED=1 ../tenent-replay-venv/bin/python \
  runtime/scripts/check_change_cases.py --store store \
  --report ../readiness-reproduced.json
```

This runs all stored cases and all 500 properties using the original engine. It makes no provider calls and writes the report outside the Store. The recorded result has five partial cases and exit code 1; do not relabel that as a passing data-readiness result. Full evaluation may take substantial time. The optional parallel research helper expects a Git checkout for revision reporting; use the serial command above for this standalone archive.

## Limitations retained

The base Store was reconstructed from previously hosted API responses. Historical provider artifacts for older retained rules were not available; fresh provider lineage covers the explicit repair runs and does not retroactively validate the other retained rules. Original source text and property inputs were preserved.

The six v5 targets have zero registered-enum mismatch issues and zero missing field-evidence issues, but still have 23 other review-issue occurrences. These include source-definition/actor-class interpretation, H5222 exemption uncertainty, unspecified CPI inputs, municipal effective dates and penalty versions, and garbled disclosure wording. H5222's interest remedy was consolidated into penalties; two general pleading provisions are retained in notes instead of structured rules. Fewer rules or issue strings do not prove complete coverage.

The property package reproduces software output, not legal accuracy. Current source admission, unknown facts, partial extraction, unavailable historical provenance and non-exhaustive planning remain visible. No provider rerun, automatic deployment, original-record alteration, or additional spending is authorized by this archive.

Repository distribution path: `docs/change_case_results/final-research-archive.zip`.
