"""Run full canonical case requests in at most three independent processes.

No rule/property filtering, provider calls or input Store writes. The final
report is built by unchanged scripts.check_change_cases.check_store. Its one
evaluation callback consumes the workers' exact full ChangeResults and re-pins
their consumed files; it does not reimplement case interpretation or readiness.
"""
from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor, as_completed
from hashlib import sha256
import json
import multiprocessing
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import time
from unittest.mock import patch

os.environ["PYTHON_DOTENV_DISABLED"] = "1"


def snapshot(root):
    root = Path(root)
    if root.is_symlink() or not root.is_dir():
        raise ValueError("Input Store must be a regular directory")
    values = {}
    for path in sorted(root.rglob("*")):
        if path.is_symlink():
            raise ValueError("Input Store must not contain symlinks")
        if path.is_file():
            if path.name.startswith(".env") or path.suffix == ".tmp":
                raise ValueError("Credential or in-progress temporary file found in input Store")
            values[path.relative_to(root).as_posix()] = sha256(path.read_bytes()).hexdigest()
    return values


def code_snapshot(repo):
    names = [p.relative_to(repo) for p in (repo / "navigator").glob("*.py")]
    names += [Path("scripts/check_change_cases.py"), Path("scripts/audit_sources.py"),
              Path("config/test_rule_selectors.json")]
    return {str(name): sha256((repo / name).read_bytes()).hexdigest() for name in sorted(names)}


def worker(repo, root, test_id, expected_code):
    started = time.perf_counter()
    repo = Path(repo)
    if code_snapshot(repo) != expected_code:
        raise ValueError("Evaluator code changed before worker start")
    sys.path.insert(0, str(repo))
    from navigator.evidence import EvidenceStoreView, prepare_rules
    from navigator.models import ChangeRequest
    from navigator.store import cached_changes, digest
    from scripts.check_change_cases import ReadOnlyStore, _validate_inputs
    store = ReadOnlyStore(Path(root))
    cases = _validate_inputs(store)
    if sum(case["test_id"] == test_id for case in cases) != 1:
        raise ValueError("Worker case does not uniquely exist in unchanged Store")
    prepared, _ = prepare_rules(store)
    prepared_sha = digest({k: v.model_dump(mode="json") for k, v in prepared.items()})
    request = ChangeRequest(test_id=test_id)
    # Same real callback used by canonical check_store, with every prepared rule.
    result, evaluation_error = None, None
    try:
        result = cached_changes(EvidenceStoreView(store, prepared), request)
    except (KeyError, TypeError, ValueError) as exc:
        # Canonical check_store reports these per case and continues. Preserve
        # their exact displayed text instead of aborting all parallel workers.
        evaluation_error = str(exc)
    store.verify_unchanged()
    if code_snapshot(repo) != expected_code:
        raise ValueError("Evaluator code changed during worker evaluation")
    return {"test_id": test_id, "request": request.model_dump(mode="json"),
            "result": result.model_dump(mode="json") if result is not None else None,
            "evaluation_error": evaluation_error, "prepared_rules_sha256": prepared_sha,
            "input_files_sha256": store.file_hashes, "input_unchanged": True,
            "rules": len(prepared), "properties": len(store.addresses()),
            "elapsed_seconds": round(time.perf_counter() - started, 4), "process_id": os.getpid()}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--store", required=True, type=Path)
    parser.add_argument("--report", required=True, type=Path)
    parser.add_argument("--metadata-report", type=Path)
    parser.add_argument("--workers", type=int, choices=[1, 2, 3], default=3)
    parser.add_argument("--expected-properties", type=int, default=500)
    args = parser.parse_args()
    started = time.perf_counter()
    repo, root, destination = args.repo.resolve(), args.store.resolve(), args.report.resolve()
    metadata_destination = (args.metadata_report or destination.with_name(destination.stem + "-parallel-metadata.json")).resolve()
    if destination == metadata_destination:
        raise ValueError("Canonical report and metadata report must differ")
    for path in (destination, metadata_destination):
        if path == root or path.is_relative_to(root):
            raise ValueError("Reports must be outside the input Store")
    initial_files, initial_code = snapshot(root), code_snapshot(repo)
    sys.path.insert(0, str(repo))
    import scripts.check_change_cases as canonical
    from navigator.models import ChangeResult
    from navigator.store import digest
    pinned = canonical.ReadOnlyStore(root)
    cases = canonical._validate_inputs(pinned)
    if len(pinned.addresses()) != args.expected_properties:
        raise ValueError("Property count differs from the explicitly requested full dataset")
    latest = pinned.read("latest_extract.json", {})
    if latest and (latest.get("outcome") == "running" or not latest.get("finished_at")):
        raise ValueError("Extraction has not reached a completed snapshot")
    required = set(canonical.DEFAULT_REQUIRED_IDS)
    if required - {case["test_id"] for case in cases}:
        raise ValueError("Full T1–T5 case definitions are required")
    tasks = sorted(case["test_id"] for case in cases)
    code_revision = subprocess.check_output(["git", "-C", str(repo), "rev-parse", "HEAD"], text=True).strip()
    print(json.dumps({"status": "started", "cases": tasks, "workers": args.workers,
                      "rules": len(pinned.rules()), "properties": len(pinned.addresses()),
                      "code_revision": code_revision}), flush=True)
    results = {}
    with ProcessPoolExecutor(max_workers=args.workers, mp_context=multiprocessing.get_context("spawn")) as pool:
        futures = {pool.submit(worker, str(repo), str(root), ident, initial_code): ident for ident in tasks}
        for future in as_completed(futures):
            value = future.result()
            results[value["test_id"]] = value
            print(json.dumps({"status": "case_evaluated", "test_id": value["test_id"],
                              "elapsed_seconds": value["elapsed_seconds"],
                              "full_rules": value["rules"], "full_properties": value["properties"]}), flush=True)
    if snapshot(root) != initial_files or code_snapshot(repo) != initial_code:
        raise ValueError("Store or evaluator code changed during parallel evaluation; no report accepted")
    consumed = set()

    def exact_worker_result(view, request):
        ident = request.test_id
        if ident in consumed or ident not in results:
            raise ValueError("Unexpected canonical callback request")
        value = results[ident]
        if request.model_dump(mode="json") != value["request"]:
            raise ValueError("Canonical request differs from worker request")
        if digest({k: v.model_dump(mode="json") for k, v in view.rules().items()}) != value["prepared_rules_sha256"]:
            raise ValueError("Canonical prepared rules differ from worker prepared rules")
        for name, expected in value["input_files_sha256"].items():
            # Include optional cache reads in canonical file hashes, as serial
            # cached_changes would. No cache files are written by either path.
            view.read(name)
            if view.file_hashes[name] != expected:
                raise ValueError("Canonical input differs from worker input: " + name)
        consumed.add(ident)
        if value["evaluation_error"] is not None:
            # Canonical stores str(exc), not its exception class. ValueError
            # preserves the original KeyError quotes and other message text.
            raise ValueError(value["evaluation_error"])
        return ChangeResult.model_validate(value["result"])

    # All validation, missing-ref handling, blocker checks and report fields are
    # the canonical function itself. Only expensive evaluated requests are reused.
    with patch.object(canonical, "cached_changes", exact_worker_result):
        report = canonical.check_store(root)
    if consumed != set(tasks):
        raise ValueError("Canonical aggregation did not consume every worker result")
    pinned.verify_unchanged()
    if snapshot(root) != initial_files or code_snapshot(repo) != initial_code:
        raise ValueError("Store or evaluator code changed before final report publication")
    elapsed = round(time.perf_counter() - started, 4)
    metadata = {
        "report_type": "parallel_full_case_evaluation_provenance",
        "canonical_report": str(destination), "store": str(root), "code_revision": code_revision,
        "code_files_sha256": initial_code, "all_store_files_sha256": initial_files,
        "worker_count_limit": args.workers, "elapsed_seconds": elapsed,
        "input_unchanged": True, "code_unchanged": True, "provider_calls": 0,
        "cases": [{k: v for k, v in results[ident].items() if k not in {"result", "input_files_sha256"}}
                  | {"consumed_input_hashes_sha256": digest(results[ident]["input_files_sha256"]),
                     "full_change_result_sha256": digest(results[ident]["result"]) if results[ident]["result"] is not None else None}
                  for ident in tasks],
        "method": "Independent real full-rule/full-property cached_changes requests; unmodified canonical check_store aggregation with exact validated worker results.",
        "limitations": ["Readiness is not an official competition score or independent legal validation.",
                        "Store provenance/admission limits are unchanged by parallel evaluation."],
    }
    for path, data in ((destination, report), (metadata_destination, metadata)):
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = None
        try:
            # Exclusive unpredictable temp files never follow a pre-existing
            # sibling .tmp symlink or overwrite another task's temporary file.
            with tempfile.NamedTemporaryFile(mode="w", encoding="utf-8", dir=path.parent,
                                             prefix="." + path.name + ".", suffix=".tmp", delete=False) as stream:
                temp = Path(stream.name)
                stream.write(json.dumps(data, indent=2, ensure_ascii=False) + "\n")
            temp.replace(path)
        finally:
            if temp is not None:
                temp.unlink(missing_ok=True)
    exit_code = 0 if report["ready"] else 1
    print(json.dumps({"status": "complete", "ready": report["ready"], "exit_code": exit_code,
                      "report": str(destination), "metadata_report": str(metadata_destination),
                      "elapsed_seconds": elapsed, "input_unchanged": True}), flush=True)
    return exit_code


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "invalid_or_changed_input", "error": str(exc), "provider_calls": 0}), flush=True)
        raise SystemExit(2)
