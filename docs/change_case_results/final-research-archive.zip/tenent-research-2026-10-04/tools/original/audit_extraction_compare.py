"""Read-only extraction comparison, never a provider runner or readiness gate.

Requires an atomic completed latest extraction snapshot. It rejects an output
Store whose files change during the audit. Partial batch progress is reported
explicitly and may be audited only between completed document runs.
"""
from __future__ import annotations

import argparse
from collections import Counter
from datetime import datetime, timezone
from hashlib import sha256
import json
import os
from pathlib import Path
import subprocess
import sys
import time

os.environ["PYTHON_DOTENV_DISABLED"] = "1"


def parse_args():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", type=Path, required=True)
    p.add_argument("--base", type=Path, required=True)
    p.add_argument("--output-store", type=Path, required=True)
    p.add_argument("--report", type=Path, required=True)
    return p.parse_args()


def fields_changed(before, after):
    return sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))


def main():
    args = parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    from navigator.changes import map_references
    from navigator.evidence import all_evidence, prepare_rules
    from navigator.models import RuleDraft
    from navigator.extraction import stable_id
    from navigator.source_policy import POLICY_VERSION, rule_source_issues, source_use
    from scripts.check_change_cases import ReadOnlyStore, _validate_inputs

    started = time.perf_counter()
    base_root, out_root, destination = args.base.resolve(), args.output_store.resolve(), args.report.resolve()
    for root in (base_root, out_root):
        if destination == root or destination.is_relative_to(root):
            raise ValueError("Report must be outside both input Stores")
    if base_root == out_root:
        raise ValueError("Base and output Stores must differ")
    base, output = ReadOnlyStore(base_root), ReadOnlyStore(out_root)
    latest = output.read("latest_extract.json", {})
    if (latest.get("operation") != "extract" or latest.get("outcome") not in {"success", "partial", "failed"}
            or not latest.get("finished_at") or not latest.get("run_id")):
        print(json.dumps({"status": "wait_for_completed_atomic_run", "provider_calls": 0}))
        return 3
    if output.read(f"runs/{latest['run_id']}.json") != latest:
        raise ValueError("Latest extraction pointer and completed run manifest differ")
    # No incomplete provider output is opened before the completed atomic marker.
    plan = output.read("change_case_extraction_plan.json", {})
    if not plan.get("jobs"):
        raise ValueError("Missing pinned change-case extraction plan")
    base_cases, new_cases = _validate_inputs(base), _validate_inputs(output)
    br, nr, bs, ns = base.rules(), output.rules(), base.sources(), output.sources()
    bi, ni = base.read("extraction_index.json", {}), output.read("extraction_index.json", {})
    bp, be = prepare_rules(base)
    np, ne = prepare_rules(output)
    planned_ids = {j["doc_id"] for j in plan["jobs"]}
    base_ids, new_ids = set(br), set(nr)
    common = base_ids & new_ids
    changed_ids = {rid for rid in common if br[rid] != nr[rid]}
    unchanged_ids = common - changed_ids
    runs = {}
    for path in sorted((out_root / "runs").glob("*.json")):
        value = output.read(path.relative_to(out_root).as_posix())
        if value.get("operation") == "extract":
            if value.get("outcome") == "running" or not value.get("finished_at"):
                raise ValueError("Output contains an unfinished extraction run; retry after completion")
            runs[value["run_id"]] = value
    ledger = output.read("change_case_budget.json", {})
    ledger_response_ids = {r.get("response_id") for r in ledger.get("requests", []) if r.get("response_id")}
    lineage = {}
    for run_id, run in runs.items():
        artifacts = []
        accepted_ids = set()
        usage = output.read(f"provider_outputs/{run_id}/usage.json", [])
        for path in sorted((out_root / "provider_outputs" / run_id).glob("*.json")):
            rel = path.relative_to(out_root).as_posix()
            data = output.read(rel)
            item = {"path": rel, "sha256": output.file_hashes[rel]}
            if isinstance(data, dict):
                item.update(source_kind=data.get("source_kind"), rules=len(data.get("rules", [])),
                            issues=data.get("issues", []), notes=data.get("notes", []))
                if path.name.endswith(("-review.json", "-repair.json")):
                    for draft in data.get("rules", []):
                        try:
                            accepted_ids.add(stable_id(RuleDraft.model_validate(draft)))
                        except ValueError:
                            # Invalid pre-repair reviews remain recorded artifacts.
                            item["contains_invalid_rule_draft"] = True
            artifacts.append(item)
        source_hash_mismatches = {ident: value for ident, value in run.get("input_hashes", {}).items()
                                  if ident not in ns or ns[ident].sha256 != value}
        lineage[run_id] = {
            "manifest": run,
            "artifacts": artifacts,
            "provider_usage": usage,
            "provider_response_count": len(usage),
            "provider_responses_linked_to_budget": all(u.get("response_id") in ledger_response_ids for u in usage),
            "review_or_repair_candidate_ids": sorted(accepted_ids),
            "input_hash_mismatches": source_hash_mismatches,
        }

    def rule_summary(rule, prepared, evidence, sources):
        run = lineage.get(rule.extraction_run_id)
        ids = {rule.source_doc_id} | {e.doc_id for e in all_evidence(rule)}
        manifest_hashes = run["manifest"].get("input_hashes", {}) if run else {}
        original = br.get(rule.team_rule_id)
        return {
            "team_rule_id": rule.team_rule_id, "source_doc_id": rule.source_doc_id,
            "citation": rule.citation, "title": rule.title, "requirement": rule.requirement,
            "provision_key": rule.provision_key, "lifecycle": rule.lifecycle,
            "effective_date": rule.effective_date, "end_date": rule.end_date,
            "status_as_of": rule.status_as_of,
            "status_events": [x.model_dump(mode="json") for x in rule.status_events],
            "coverage_conditions": rule.coverage_conditions.model_dump(mode="json"),
            "exemption_conditions": rule.exemption_conditions.model_dump(mode="json"),
            "interactions": [x.model_dump(mode="json") for x in rule.interactions],
            "review_issues": rule.review_issues, "prepared_review_issues": prepared.review_issues,
            "semantic_verification": rule.semantic_verification,
            "prepared_semantic_verification": prepared.semantic_verification,
            "evidence_blockers": evidence.blocking_issues,
            "source_policy_issues": rule_source_issues(rule, sources),
            "evidence_mode": rule.evidence_mode, "extraction_run_id": rule.extraction_run_id,
            "lineage_manifest_available": run is not None,
            "lineage_evidence_inputs_match": bool(run) and all(
                ident in sources and manifest_hashes.get(ident) == sources[ident].sha256 for ident in ids),
            "lineage_review_candidate_id_present": bool(run) and any(
                rule.team_rule_id == candidate or rule.team_rule_id.startswith(candidate + "-")
                for candidate in run["review_or_repair_candidate_ids"]),
            "retained_from_base_identically": original == rule if original else False,
            "retains_base_extraction_origin": original.extraction_run_id == rule.extraction_run_id if original else False,
        }

    per_source = []
    for ident in sorted(set(bs) | set(ns) | planned_ids):
        old_source, new_source = bs.get(ident), ns.get(ident)
        old_rules = {k for k, r in br.items() if r.source_doc_id == ident}
        new_rules = {k for k, r in nr.items() if r.source_doc_id == ident}
        source_delta = fields_changed(old_source.model_dump() if old_source else {}, new_source.model_dump() if new_source else {})
        if ident not in planned_ids and not source_delta and bi.get(ident) == ni.get(ident) and old_rules == new_rules and not new_rules & changed_ids:
            continue
        index = ni.get(ident, {})
        run = runs.get(index.get("run_id"))
        index_lineage_matches = bool(run and new_source) and (
            index.get("sha256") == new_source.sha256
            and run.get("input_hashes", {}).get(ident) == new_source.sha256)
        per_source.append({
            "doc_id": ident, "planned_primary": ident in planned_ids,
            "source_changed_fields": source_delta,
            "original_text_unchanged": old_source.text == new_source.text if old_source and new_source else None,
            "before_sha256": old_source.sha256 if old_source else None,
            "after_sha256": new_source.sha256 if new_source else None,
            "before_source_type": old_source.source_type if old_source else None,
            "after_source_type": new_source.source_type if new_source else None,
            "after_policy": source_use(new_source).__dict__ if new_source else None,
            "before_index": bi.get(ident), "after_index": index or None,
            "new_completed_run": index_lineage_matches and bool(run.get("finished_at")),
            "index_source_and_run_identity_match": index_lineage_matches,
            "new_run_outcome": run.get("outcome") if run else None,
            "old_rule_ids": sorted(old_rules), "new_rule_ids": sorted(new_rules),
            "added_ids": sorted(new_rules - old_rules), "removed_ids": sorted(old_rules - new_rules),
            "unchanged_retained_ids": sorted(new_rules & unchanged_ids),
            "changed_same_ids": sorted(new_rules & changed_ids),
            "retained_old_origin_ids": sorted(k for k in old_rules & new_rules if br[k].extraction_run_id == nr[k].extraction_run_id),
        })
    case_comparison = []
    relevant = set(new_ids - base_ids) | changed_ids
    for case in new_cases:
        refs = list(dict.fromkeys(case.get("rule_ids", []) + case.get("conflict_with", [])))
        old_map = map_references(list(br.values()), refs)
        new_map = map_references(list(nr.values()), refs)
        old_related = {rid for values in old_map.values() for rid in values}
        new_related = {rid for values in new_map.values() for rid in values}
        relevant.update(new_related)
        case_comparison.append({
            "test_id": case["test_id"], "before_mapping": old_map, "after_mapping": new_map,
            "added_mapped_ids": sorted(new_related - old_related),
            "removed_mapped_ids": sorted(old_related - new_related),
            "remaining_missing_refs": sorted(ref for ref, ids in new_map.items() if not ids),
            "retained_old_origin_ids": sorted(k for k in old_related & new_related if br[k].extraction_run_id == nr[k].extraction_run_id),
            "before_rule_details": {k: rule_summary(br[k], bp[k], be[k], bs) for k in sorted(old_related)},
            "after_rule_ids": sorted(new_related),
        })
    completed = {row["doc_id"] for row in per_source if row["planned_primary"] and row["new_completed_run"]}
    successful = {row["doc_id"] for row in per_source if row["planned_primary"] and row["new_completed_run"] and row["new_run_outcome"] == "success"}
    report = {
        "report_type": "read_only_extraction_comparison_not_release_or_legal_validation",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "code_revision": subprocess.check_output(["git", "-C", str(args.repo), "rev-parse", "HEAD"], text=True).strip(),
        "source_policy_version": POLICY_VERSION,
        "base": str(base_root), "output_store": str(out_root),
        "latest_completed_run": latest["run_id"],
        "planned_primary_ids": sorted(planned_ids), "completed_primary_ids": sorted(completed),
        "successful_primary_ids": sorted(successful),
        "remaining_primary_ids": sorted(planned_ids - completed),
        "all_planned_jobs_successful": successful == planned_ids,
        "counts": {"before_rules": len(br), "after_rules": len(nr), "before_sources": len(bs), "after_sources": len(ns),
                   "added_rules": len(new_ids - base_ids), "removed_rules": len(base_ids - new_ids),
                   "changed_same_ids": len(changed_ids), "unchanged_retained_rules": len(unchanged_ids),
                   "before_index_statuses": dict(Counter(v.get("status") for v in bi.values())),
                   "after_index_statuses": dict(Counter(v.get("status") for v in ni.values()))},
        "added_rule_ids": sorted(new_ids - base_ids), "removed_rule_ids": sorted(base_ids - new_ids),
        "changed_rules": {rid: {"changed_fields": fields_changed(br[rid].model_dump(), nr[rid].model_dump()),
                                "old_review_issues": br[rid].review_issues, "new_review_issues": nr[rid].review_issues,
                                "old_evidence_blockers": be[rid].blocking_issues, "new_evidence_blockers": ne[rid].blocking_issues}
                          for rid in sorted(changed_ids)},
        "sources": per_source, "cases": case_comparison,
        "removed_and_changed_original_rule_details": {rid: rule_summary(br[rid], bp[rid], be[rid], bs)
                                                       for rid in sorted((base_ids - new_ids) | changed_ids)},
        "new_and_mapped_rule_details": {rid: rule_summary(nr[rid], np[rid], ne[rid], ns) for rid in sorted(relevant)},
        "provider_run_lineage": lineage, "budget_ledger": ledger,
        "case_definitions_unchanged": base_cases == new_cases,
        "property_inputs_unchanged": all(base.file_hashes.get(k) == output.file_hashes.get(k)
                                         for k in ("addresses.json", "resolutions.json")),
        "provider_calls_by_this_audit": 0,
        "limitations": ["Mapping/blocker comparison only; does not execute the all-address readiness gate.",
                        "Original API reconstruction lacks historic provider files; unavailable lineage is explicit.",
                        "Extraction success/model review is not source admission or independent legal verification.",
                        "No old blocker is reclassified or removed by this read-only audit."],
    }
    # These cover the completed marker, all consumed inputs and provider artifacts.
    base.verify_unchanged()
    output.verify_unchanged()
    report.update(input_unchanged=True, base_files_sha256=base.file_hashes,
                  output_files_sha256=output.file_hashes, elapsed_seconds=round(time.perf_counter() - started, 4))
    destination.parent.mkdir(parents=True, exist_ok=True)
    temp = destination.with_suffix(destination.suffix + ".tmp")
    temp.write_text(json.dumps(report, indent=2, ensure_ascii=False, default=str) + "\n")
    temp.replace(destination)
    print(json.dumps({"status": "audited_stable_completed_snapshot", "report": str(destination),
                      "counts": report["counts"], "remaining_primary_ids": report["remaining_primary_ids"],
                      "all_planned_jobs_successful": report["all_planned_jobs_successful"],
                      "input_unchanged": True, "elapsed_seconds": report["elapsed_seconds"]}))
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print(json.dumps({"status": "audit_not_completed", "error": str(exc), "provider_calls": 0}))
        raise SystemExit(2)
