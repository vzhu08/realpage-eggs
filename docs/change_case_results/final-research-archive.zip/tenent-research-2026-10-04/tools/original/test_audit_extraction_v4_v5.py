"""Offline temporary-fixture checks; never reads actual extraction output."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest

spec = importlib.util.spec_from_file_location('audit', Path(__file__).with_name('audit_extraction_v4_v5.py'))
audit = importlib.util.module_from_spec(spec)
spec.loader.exec_module(audit)


class AuditTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.before, self.after = self.root / 'before', self.root / 'after'
        for path in (self.before, self.after):
            self.make_store(path)

    def write(self, root, name, value):
        path = root / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(json.dumps(value))

    def read(self, root, name):
        return json.loads((root / name).read_text())

    def make_store(self, root):
        text = 'This is a fictional retained source for a local audit fixture.'
        rules, sources, index, jobs = {}, {}, {}, []
        for number, doc in enumerate(audit.TARGETS):
            run_id, rule_id = f'run-{number}', f'rule-{number}'
            source = {'text': text, 'sha256': audit.sha(text.encode()), 'url': 'https://example.invalid/fixture'}
            sources[doc] = source
            run = {'run_id': run_id, 'operation': 'extract', 'mode': 'live', 'outcome': 'success',
                   'finished_at': '2026-01-01T00:00:00+00:00', 'input_hashes': {doc: source['sha256']},
                   'config': {'prompt_version': 'extract-v5-fixture', 'fact_contract_sha256': 'a' * 64}}
            self.write(root, f'runs/{run_id}.json', run)
            index[doc] = {'run_id': run_id, 'status': 'review'}
            jobs.append({'doc_id': doc, 'run_id': run_id, 'outcome': 'success'})
            rules[rule_id] = {'team_rule_id': rule_id, 'source_doc_id': doc, 'source_url': source['url'],
                             'quoted_span': text, 'extraction_run_id': run_id, 'provision_key': 'fixture',
                             'jurisdiction': 'XX', 'category': 'fictional', 'citation': 'Fictional section',
                             'lifecycle': 'unknown', 'evidence': [{'doc_id': doc, 'quote': text, 'start': 0,
                                                                'end': len(text), 'supports': ['requirement']}],
                             'review_issues': ['Missing field-level evidence for exemption_conditions',
                                               'Genuine fixture qualification remains unresolved.']}
        for name, value in [('rules.json', rules), ('sources.json', sources),
                            ('extraction_index.json', index), ('latest_extract.json', run)]:
            self.write(root, name, value)
        self.write(root, 'v5_continuation_result.json', {'jobs': jobs, 'remaining_doc_ids': [],
                                                       'original_input_unchanged': True})
        self.receipt(root)

    def receipt(self, root):
        self.write(root, 'execution_completion.json', {'exit_code': 0,
                   'result_sha256': audit.sha((root / 'v5_continuation_result.json').read_bytes())})

    def test_complete_report_preserves_other_uncertainty_and_input_bytes(self):
        raw = {path: path.read_bytes() for root in (self.before, self.after) for path in root.rglob('*.json')}
        report = self.root / 'audit.json'
        with contextlib.redirect_stdout(io.StringIO()):
            audit.main(['--before', str(self.before), '--after', str(self.after), '--report', str(report)])
        value = json.loads(report.read_text())
        self.assertEqual(value['totals']['after']['missing_field_evidence_occurrences'], 6)
        for doc in value['after'].values():
            self.assertFalse(doc['lineage_findings'])
            self.assertEqual(doc['rules'][0]['review_issues']['other_review_issue_unclassified'],
                             ['Genuine fixture qualification remains unresolved.'])
        self.assertTrue(all(path.read_bytes() == data for path, data in raw.items()))

    def test_missing_or_stale_receipt_refuses_before_reading_rules(self):
        (self.after / 'execution_completion.json').unlink()
        snap = audit.Snapshot(self.after)
        with self.assertRaises(ValueError):
            audit.completed_jobs(snap)
        self.assertNotIn('rules.json', snap.raw)
        self.receipt(self.after)
        result = self.read(self.after, 'v5_continuation_result.json')
        result['unrelated_change'] = True
        self.write(self.after, 'v5_continuation_result.json', result)
        with self.assertRaisesRegex(ValueError, 'post-exit receipt'):
            audit.completed_jobs(audit.Snapshot(self.after))

    def test_incomplete_or_duplicate_jobs_refuse(self):
        result = self.read(self.after, 'v5_continuation_result.json')
        result['jobs'][-1] = result['jobs'][0]
        self.write(self.after, 'v5_continuation_result.json', result)
        self.receipt(self.after)
        with self.assertRaisesRegex(ValueError, 'targets are not all terminal'):
            audit.completed_jobs(audit.Snapshot(self.after))

    def test_active_manifest_refuses(self):
        run = self.read(self.after, 'runs/run-0.json')
        run['outcome'], run['finished_at'] = 'running', None
        self.write(self.after, 'runs/run-0.json', run)
        with self.assertRaisesRegex(ValueError, 'nonterminal run'):
            audit.summarize(audit.Snapshot(self.after))

    def test_changed_bytes_refuse(self):
        snap = audit.Snapshot(self.after)
        snap.read('rules.json')
        self.write(self.after, 'rules.json', {})
        with self.assertRaisesRegex(ValueError, 'Active/changing Store'):
            snap.verify_unchanged()

    def test_bad_quote_and_undeclared_source_stay_findings(self):
        rules = self.read(self.after, 'rules.json')
        span = rules['rule-0']['evidence'][0]
        span['doc_id'], span['quote'] = 'UNPROVIDED', 'Unprovided and invented fixture quote.'
        self.write(self.after, 'rules.json', rules)
        docs = audit.summarize(audit.Snapshot(self.after))
        findings = [f['finding'] for f in docs[audit.TARGETS[0]]['lineage_findings']]
        self.assertTrue(any('not declared' in f for f in findings))
        self.assertTrue(any('quote/anchor mismatch' in f for f in findings))


if __name__ == '__main__':
    unittest.main()
