"""Six explicit v5 research re-extractions; dry-run default, same total $5 cap.

Original source-bundle contexts, plans, caches and provider lineage are preserved
in a new full Store copy. Only existing Core extraction may replace candidates.
"""
import argparse
from decimal import Decimal
import json
import os
from pathlib import Path
import shutil
import sys

os.environ["PYTHON_DOTENV_DISABLED"] = "1"
TARGETS = {"D069", "P11_MA_H5222_TEXT", "P11_MA_IP25_21_ORIGINAL", "P11_MA_S2983_TEXT",
           "P11_NJ_JC_25_057", "P11_NJ_JC_25_098"}
TOTAL_AUTHORIZED = Decimal("5")
V2_MANIFEST_SHA256 = "5be99377ba5407a8dafd78f9b78d92325f794cb67dd5974d863b583dbda5b8f9"


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--repo", required=True, type=Path)
    p.add_argument("--source-dir", required=True, type=Path)
    p.add_argument("--output", required=True, type=Path)
    p.add_argument("--env-file", type=Path)
    p.add_argument("--execute", action="store_true")
    p.add_argument("--expected-plan-sha256", help="Execution requires the exact reviewed dry-run plan SHA")
    args = p.parse_args()
    repo = args.repo.resolve()
    sys.path.insert(0, str(repo))
    import httpx
    from dotenv import dotenv_values
    from navigator.extraction import (PROMPT_VERSION, OpenAIProvider, chunks, extract, supporting_documents)
    from navigator.source_policy import source_use
    from navigator.store import Store, digest, write_json
    from scripts.extract_change_cases import _files, _load, request_sizes
    from scripts.extraction_batch import BudgetClient, INPUT_RATE, OUTPUT_RATE, RESERVATION
    from scripts.extraction_pilot import MODEL, MAX_OUTPUT_TOKENS, configure_credentials

    if not PROMPT_VERSION.startswith("extract-v5-"):
        if args.execute:
            raise ValueError("Execution requires the integrated v5 fact-contract prompt; v4 is prohibited")
        print(json.dumps({"status": "wait_for_integrated_v5_runtime", "prompt_version": PROMPT_VERSION,
                          "provider_calls": 0, "store_writes": 0}))
        return 3
    source, output = args.source_dir.resolve(), args.output.absolute()
    if output.exists() or output.is_symlink() or any(
        output.resolve().is_relative_to(x) or x.is_relative_to(output.resolve()) for x in (source, repo)
    ):
        raise ValueError("Output must be new and separate from source Store and repository")
    if any(path.name.startswith(".env") for path in source.rglob("*")):
        raise ValueError("Credential file found in source Store; no copy permitted")
    hashes = _files(source)
    code_paths = list((repo / "navigator").glob("*.py")) + [repo / "scripts" / name for name in
                  ("extract_change_cases.py", "extraction_batch.py", "extraction_pilot.py")]
    runtime = {str(path.relative_to(repo)): digest(path.read_bytes()) for path in sorted(code_paths)}
    latest = _load(source / "latest_extract.json")
    if latest.get("outcome") not in {"success", "partial", "failed"} or not latest.get("finished_at"):
        raise ValueError("Previous batch has not reached a completed snapshot")
    if latest != _load(source / "runs" / (latest["run_id"] + ".json")):
        raise ValueError("Latest marker and run manifest differ")
    for path in (source / "runs").glob("*.json"):
        run = _load(path)
        if run.get("operation") != "extract":
            continue
        if run.get("outcome") == "running" or not run.get("finished_at"):
            raise ValueError("An extraction run remains unfinished")
        primary_ids = set(run.get("config", {}).get("primary_doc_ids", []))
        if run.get("config", {}).get("prompt_version", "").startswith("extract-v5-") and primary_ids & TARGETS:
            raise ValueError("A targeted v5 extraction already exists; inspect its lineage before spending again")
    ledger_path = source / "change_case_budget.json"
    ledger = _load(ledger_path)
    if ledger.get("model") != MODEL or Decimal(ledger["budget_usd"]) != TOTAL_AUTHORIZED:
        raise ValueError("Continuation must preserve the original model and SAME total $5 allocation")
    charged = Decimal("0")
    for entry in ledger["requests"]:
        incoming, outgoing = (entry.get("usage", {}).get(key) for key in ("input_tokens", "output_tokens"))
        if (entry.get("status") != "usage_recorded" or type(incoming) is not int or type(outgoing) is not int
                or not 0 <= incoming < 272000 or not 0 <= outgoing <= MAX_OUTPUT_TOKENS):
            raise ValueError("Prior billing/usage remains unreconciled")
        charge = incoming * INPUT_RATE + outgoing * OUTPUT_RATE
        if charge != Decimal(entry["upper_estimate_usd"]) or charge > RESERVATION:
            raise ValueError("Prior usage/rate mismatch")
        charged += charge
    if charged != Decimal(ledger["charged_upper_estimate_usd"]) or charged > TOTAL_AUTHORIZED:
        raise ValueError("Prior cumulative total mismatch")
    if charged + RESERVATION > TOTAL_AUTHORIZED:
        raise ValueError("Same $5 cap cannot reserve another request")
    original_plan = _load(source / "change_case_extraction_plan.json")
    bundle_root = source / "change_case_source_bundle"
    bundle_files = _files(bundle_root)
    if (bundle_files != original_plan.get("input_files_sha256", {}).get("source_bundle")
            or bundle_files.get("manifest.json") != V2_MANIFEST_SHA256):
        raise ValueError("Original v2 source-only bundle or its preserved plan changed")
    manifest = _load(bundle_root / "manifest.json")
    if (manifest.get("label") != "SOURCE_ONLY_RESEARCH_BUNDLE_NOT_A_SUBMISSION"
            or manifest.get("sources_json_sha256") != bundle_files.get("sources.json")):
        raise ValueError("Invalid original source-only manifest identity")
    supplied, stored = Store(bundle_root).sources(), Store(source).sources()
    jobs = [j for j in manifest["extraction_jobs"] if j["doc_id"] in TARGETS]
    if len(jobs) != len(TARGETS) or {j["doc_id"] for j in jobs} != TARGETS:
        raise ValueError("Original manifest does not contain exactly the six requested primary jobs")
    details_jobs = []
    for job in jobs:
        primary = stored[job["doc_id"]]
        support = supporting_documents(stored, job["supporting_doc_ids"])
        if source_use(primary).status != "eligible_primary":
            raise ValueError("Primary is no longer eligible official legal text: " + primary.doc_id)
        for item in [primary, *support]:
            original = supplied.get(item.doc_id)
            if (original is None or not item.text or digest(item.text.encode("utf-8")) != item.sha256
                    or original.text != item.text or original.sha256 != item.sha256
                    or original.url != item.url or original.retrieved_at != item.retrieved_at):
                raise ValueError("Source differs from the exact original v2 context: " + item.doc_id)
        details_jobs.append({**job, "chunks": len(list(chunks(primary.text))),
                             "input_source_sha256": {s.doc_id: s.sha256 for s in [primary, *support]},
                             "request_sizes": request_sizes(primary, support)})
    details = {
        "label": "SIX_DOCUMENT_V5_RESEARCH_CONTINUATION_NOT_A_RELEASE",
        "source_dir": str(source), "output": str(output), "prompt_version": PROMPT_VERSION,
        "original_latest_run_id": latest["run_id"], "model": MODEL,
        "prior_ledger_sha256": hashes["change_case_budget.json"],
        "total_budget_usd_unchanged": str(TOTAL_AUTHORIZED), "prior_upper_estimate_usd": str(charged),
        "remaining_upper_estimate_usd": str(TOTAL_AUTHORIZED - charged), "reservation_usd": str(RESERVATION),
        "source_bundle_manifest_sha256": V2_MANIFEST_SHA256,
        "preserved_original_plan_sha256": hashes["change_case_extraction_plan.json"],
        "jobs": details_jobs, "maximum_additional_transport_requests": 3 * sum(j["chunks"] for j in details_jobs),
        "input_files_sha256": hashes, "runtime_files_sha256": runtime, "provider_calls_started": 0,
        "limitations": ["Cumulative authorization is unchanged; remaining allocation may not finish every job.",
                        "Core performs all draft/review/repair and candidate replacement; no hand-authored rules.",
                        "Unselected D022, SB763, ART2 and Hoboken candidates remain unchanged.",
                        "Successful extraction is not proof that all five cases pass or that a release is admissible."],
    }
    plan_sha = digest(details)
    def verify_inputs():
        if _files(source) != hashes:
            raise ValueError("Input Store changed; no further requests permitted")
        if any(digest((repo / name).read_bytes()) != value for name, value in runtime.items()):
            raise ValueError("Reviewed extractor runtime changed; no further requests permitted")
    verify_inputs()
    print(json.dumps({**details, "plan_sha256": plan_sha}, indent=2), flush=True)
    if not args.execute:
        print("DRY RUN: no credentials read, provider calls, or Store writes.")
        return 0
    if args.expected_plan_sha256 != plan_sha:
        raise ValueError("Execution requires the exact reviewed v5 dry-run plan SHA256")
    values = dotenv_values(args.env_file) if args.env_file else os.environ
    if values.get("OPENAI_MODEL") and values["OPENAI_MODEL"] != MODEL:
        raise ValueError("Configured model differs from reviewed model")
    configure_credentials(args.env_file)
    verify_inputs()
    shutil.copytree(source, output)
    output.chmod(0o700)
    if _files(output) != hashes:
        raise ValueError("Full copied Store differs from its source; no request sent")
    target = Store(output)
    protected = {k: v for k, v in target.read("rules.json").items() if v["source_doc_id"] not in TARGETS}
    write_json(target.path("v5_continuation_plan.json"), {**details, "plan_sha256": plan_sha})
    completed = []
    with httpx.Client(timeout=httpx.Timeout(120, read=600)) as transport:
        client = BudgetClient(transport, target.path("change_case_budget.json"), TOTAL_AUTHORIZED,
                              prior_ledger=ledger_path)
        for job in details_jobs:
            verify_inputs()
            provider = OpenAIProvider(client=client)
            provider.max_output_tokens = MAX_OUTPUT_TOKENS
            result = extract(target, [job["doc_id"]], provider=provider, limit=1,
                             supporting_doc_ids=job["supporting_doc_ids"])
            result.config.update(transport_attempts=1, change_case_ledger="change_case_budget.json",
                                 continuation_plan="v5_continuation_plan.json", continuation_plan_sha256=plan_sha,
                                 prior_ledger_sha256=details["prior_ledger_sha256"],
                                 source_bundle_manifest_sha256=V2_MANIFEST_SHA256, total_authorized_budget_usd="5")
            target.save_run(result)
            current = target.read("rules.json")
            if any(current.get(k) != value for k, value in protected.items()):
                raise ValueError("Unselected original rule changed; stop and preserve output for review")
            completed.append({"doc_id": job["doc_id"], "run_id": result.run_id, "outcome": result.outcome,
                              "counts": result.counts, "errors": result.errors})
            verify_inputs()
            write_json(target.path("v5_continuation_result.json"), {"label": details["label"], "jobs": completed,
                "original_input_unchanged": True, "ready_for_submission": False,
                "remaining_doc_ids": [j["doc_id"] for j in details_jobs[len(completed):]]})
            print(json.dumps(completed[-1]), flush=True)
            if result.outcome != "success":
                return 1
    print("Six v5 jobs completed; evaluate the immutable output before any release or submission.", flush=True)
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print("Cannot continue v5 extraction: " + str(exc), file=sys.stderr)
        raise SystemExit(2)
