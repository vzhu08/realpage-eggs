"""One explicit ART2 research extraction in a new copy; dry-run by default.

Uses the existing Core extractor and BudgetClient. This helper never changes the
total authorization, deletes old candidates manually, deploys, or exports.
"""
import argparse
from decimal import Decimal
import json
import os
from pathlib import Path
import shutil
import sys

os.environ["PYTHON_DOTENV_DISABLED"] = "1"
PRIMARY = "P11_CA_BPC_ART2"
SUPPORT = ["P11_CA_AB325_HISTORY", "P11_CA_BPC_ART1"]
TOTAL_AUTHORIZED = Decimal("5")


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--repo", required=True, type=Path)
    parser.add_argument("--source-dir", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--env-file", type=Path)
    parser.add_argument("--execute", action="store_true")
    parser.add_argument("--expected-latest-run-id", help="Required for execution; copy from reviewed dry-run")
    parser.add_argument("--expected-ledger-sha256", help="Required for execution; copy from reviewed dry-run")
    args = parser.parse_args()
    sys.path.insert(0, str(args.repo.resolve()))
    import httpx
    from dotenv import dotenv_values
    from navigator.extraction import (CONTEXT_VERSION, PROMPT_VERSION, VERSION, OpenAIProvider,
        chunks, extract, supporting_documents, supporting_payload)
    from navigator.models import ExtractionBundle
    from navigator.source_policy import source_use
    from navigator.store import Store, digest, write_json
    from scripts.extract_change_cases import _files, _load, request_sizes
    from scripts.extraction_batch import BudgetClient, INPUT_RATE, OUTPUT_RATE, RESERVATION
    from scripts.extraction_pilot import MODEL, MAX_OUTPUT_TOKENS, configure_credentials

    source = args.source_dir.resolve()
    output = args.output.absolute()
    if output.exists() or output.is_symlink() or any(
        output.resolve().is_relative_to(p) or p.is_relative_to(output.resolve()) for p in (source, args.repo.resolve())
    ):
        raise ValueError("Output must be new and separate from source Store and repository")
    if any(p.name.startswith(".env") for p in source.rglob("*")):
        raise ValueError("Unexpected credential file in the source Store; no copy or provider call made")
    hashes = _files(source)
    latest = _load(source / "latest_extract.json")
    if latest.get("outcome") not in {"success", "partial", "failed"} or not latest.get("finished_at"):
        print(json.dumps({"status": "wait_for_completed_batch_snapshot", "provider_calls": 0}))
        return 3
    if latest != _load(source / "runs" / (latest["run_id"] + ".json")):
        raise ValueError("Latest completed marker and run file differ")
    for path in (source / "runs").glob("*.json"):
        run = _load(path)
        if run.get("operation") == "extract" and (run.get("outcome") == "running" or not run.get("finished_at")):
            raise ValueError("An extraction run is unfinished; wait for the batch to stop")
    ledger_path = source / "change_case_budget.json"
    ledger = _load(ledger_path)
    if ledger.get("model") != MODEL or Decimal(ledger["budget_usd"]) != TOTAL_AUTHORIZED:
        raise ValueError("Continuation requires the original model and SAME total $5 budget")
    charged = Decimal("0")
    for entry in ledger["requests"]:
        usage = entry.get("usage", {})
        incoming, outgoing = usage.get("input_tokens"), usage.get("output_tokens")
        if (entry.get("status") != "usage_recorded" or type(incoming) is not int or type(outgoing) is not int
                or not 0 <= incoming < 272000 or not 0 <= outgoing <= MAX_OUTPUT_TOKENS):
            raise ValueError("Prior usage/billing is unreconciled; no continuation permitted")
        charge = incoming * INPUT_RATE + outgoing * OUTPUT_RATE
        if charge != Decimal(entry["upper_estimate_usd"]) or charge > RESERVATION:
            raise ValueError("Prior usage/rate mismatch; no continuation permitted")
        charged += charge
    if charged != Decimal(ledger["charged_upper_estimate_usd"]) or charged > TOTAL_AUTHORIZED:
        raise ValueError("Prior ledger total is inconsistent")
    remaining = TOTAL_AUTHORIZED - charged
    if remaining < RESERVATION:
        raise ValueError("Same $5 authorization leaves less than one reservation; no provider call permitted")
    store = Store(source)
    sources = store.sources()
    old_plan = _load(source / "change_case_extraction_plan.json")
    bundle_root = source / "change_case_source_bundle"
    if _files(bundle_root) != old_plan.get("input_files_sha256", {}).get("source_bundle"):
        raise ValueError("Original source-only bundle differs from its preserved extraction plan")
    bundled_sources = Store(bundle_root).sources()
    primary = sources[PRIMARY]
    support = supporting_documents(sources, SUPPORT)
    if source_use(primary).status != "eligible_primary":
        raise ValueError("ART2 must remain an eligible official primary source")
    for item in [primary, *support]:
        if not item.text or digest(item.text.encode("utf-8")) != item.sha256:
            raise ValueError("Exact captured source identity mismatch: " + item.doc_id)
        original = bundled_sources.get(item.doc_id)
        if (original is None or original.text != item.text or original.sha256 != item.sha256
                or original.url != item.url or original.retrieved_at != item.retrieved_at):
            raise ValueError("Source differs from its preserved original bundle: " + item.doc_id)
    sizes = request_sizes(primary, support)
    context_hash = digest([CONTEXT_VERSION, supporting_payload(support)])
    # Match Core's current identity without removing/rewriting any existing cache.
    keys = []
    for offset, text in chunks(primary.text):
        identity = [primary.doc_id, primary.sha256, primary.url, primary.retrieved_at, primary.authority,
                    MODEL, "live", PROMPT_VERSION, VERSION, ExtractionBundle.model_json_schema(), offset, text,
                    {"supporting_context_sha256": context_hash}]
        keys.append(digest(identity))
    for key in keys:
        if (source / "extraction_cache" / (key + ".json")).exists() or list(
            (source / "provider_outputs").glob("*/" + key + "-draft.json")
        ):
            raise ValueError("Exact ART2 context already has cached/draft work; inspect its lineage instead of forcing a fresh spend")
    index = store.read("extraction_index.json", {})
    old_job_status = {job["doc_id"]: index.get(job["doc_id"], {}).get("status", "unprocessed") for job in old_plan["jobs"]}
    details = {
        "label": "ONE_ART2_RESEARCH_CONTINUATION_NOT_A_RELEASE",
        "source_dir": str(source), "output": str(output), "original_latest_run_id": latest["run_id"],
        "prior_ledger_sha256": hashes["change_case_budget.json"], "model": MODEL,
        "total_budget_usd_unchanged": str(TOTAL_AUTHORIZED), "prior_upper_estimate_usd": str(charged),
        "remaining_upper_estimate_usd": str(remaining), "reservation_usd": str(RESERVATION),
        "primary_doc_id": PRIMARY, "supporting_doc_ids": SUPPORT,
        "input_source_sha256": {s.doc_id: s.sha256 for s in [primary, *support]},
        "supporting_context_sha256": context_hash, "expected_cache_keys": keys,
        "request_sizes": sizes, "maximum_additional_transport_requests": 3 * len(keys),
        "previous_plan_doc_statuses": old_job_status,
        "preserved_original_plan_sha256": hashes["change_case_extraction_plan.json"],
        "input_files_sha256": hashes, "provider_calls_started": 0,
        "limitations": ["The budget cap is cumulative across original and continuation requests; no fresh $5 allocation.",
                        "Only Core may replace ART2-owned candidates after a successful new draft/review pass.",
                        "Broad article references may remain unresolved with this bounded context.",
                        "New extraction is not independent semantic validation or a guarantee that T1 passes.",
                        "Historic API-reconstruction provenance gaps remain explicitly unresolved."],
    }
    if _files(source) != hashes:
        raise ValueError("Source Store changed during planning; wait for a stable batch snapshot")
    print(json.dumps(details, indent=2), flush=True)
    if not args.execute:
        print("DRY RUN: no credentials read, provider calls, or Store writes.")
        return 0
    if (args.expected_latest_run_id != latest["run_id"]
            or args.expected_ledger_sha256 != details["prior_ledger_sha256"]):
        raise ValueError("Execution requires the exact reviewed latest-run ID and ledger SHA256")
    values = dotenv_values(args.env_file) if args.env_file else os.environ
    if values.get("OPENAI_MODEL") and values["OPENAI_MODEL"] != MODEL:
        raise ValueError("Configured model differs from reviewed model")
    configure_credentials(args.env_file)
    if _files(source) != hashes:
        raise ValueError("Source Store changed after planning; no provider call sent")
    shutil.copytree(source, output)
    output.chmod(0o700)
    if _files(output) != hashes:
        raise ValueError("New full copy differs from source; no provider call sent")
    target = Store(output)
    # Keep change_case_extraction_plan.json and the complete source bundle intact.
    write_json(target.path("art2_continuation_plan.json"), details)
    with httpx.Client(timeout=httpx.Timeout(120, read=600)) as transport:
        client = BudgetClient(transport, target.path("change_case_budget.json"), TOTAL_AUTHORIZED,
                              prior_ledger=ledger_path)
        provider = OpenAIProvider(client=client)
        provider.max_output_tokens = MAX_OUTPUT_TOKENS
        result = extract(target, [PRIMARY], provider=provider, limit=1, supporting_doc_ids=SUPPORT)
        result.config.update(transport_attempts=1, change_case_ledger="change_case_budget.json",
                             continuation_plan="art2_continuation_plan.json",
                             prior_ledger_sha256=details["prior_ledger_sha256"],
                             original_latest_run_id=latest["run_id"], total_authorized_budget_usd="5")
        target.save_run(result)
    summary = {"label": details["label"], "run_id": result.run_id, "outcome": result.outcome,
               "counts": result.counts, "errors": result.errors,
               "original_input_unchanged": _files(source) == hashes,
               "ready_for_submission": False}
    write_json(target.path("art2_continuation_result.json"), summary)
    print(json.dumps(summary), flush=True)
    if not summary["original_input_unchanged"]:
        raise ValueError("Original input changed during execution; preserve output and inspect before any promotion")
    return 0 if result.outcome == "success" else 1


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError) as exc:
        print("Cannot continue ART2: " + str(exc), file=sys.stderr)
        raise SystemExit(2)
