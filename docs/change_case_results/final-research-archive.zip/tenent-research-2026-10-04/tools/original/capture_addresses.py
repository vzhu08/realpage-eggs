from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timezone
import httpx,json
base='https://realpage-navigator.onrender.com/api/v1'
out=Path('/tmp/tenent-t1-t5-repair')
with httpx.Client(timeout=30) as client:
    def capture(offset):
        r=client.get(base+'/addresses',params={'offset':offset,'limit':100});r.raise_for_status()
        v=r.json();assert v['total']==500 and len(v['items'])==100
        (out/f'addresses-{offset}.json').write_bytes(r.content)
        return v['items']
    health_before=client.get(base+'/health');health_before.raise_for_status()
    with ThreadPoolExecutor(max_workers=2) as pool:
        items=[row for group in pool.map(capture,range(0,500,100)) for row in group]
    health_after=client.get(base+'/health');health_after.raise_for_status()
assert len({v['property']['address_id'] for v in items})==500
(out/'address_capture.json').write_text(json.dumps({'captured_at':datetime.now(timezone.utc).isoformat(),'api':base,'health_before':health_before.json(),'health_after':health_after.json(),'count':len(items)},indent=2)+'\n')
print(json.dumps({'captured_addresses':len(items),'resolved':sum(v['resolution']['match_quality']=='resolved' for v in items),'health_counts_stable':health_before.json()==health_after.json()}))
