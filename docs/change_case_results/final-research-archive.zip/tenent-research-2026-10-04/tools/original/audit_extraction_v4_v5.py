#!/usr/bin/env python3
"""Offline, read-only comparison. Requires the root's post-exit completion receipt.

No repository imports, network libraries, environment-file reads, or Store writes.
Issue labels count machine prefixes only; other uncertainty is retained verbatim.
"""
import argparse
from collections import Counter
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path

TARGETS = (
    'D069', 'P11_MA_H5222_TEXT', 'P11_MA_IP25_21_ORIGINAL',
    'P11_MA_S2983_TEXT', 'P11_NJ_JC_25_057', 'P11_NJ_JC_25_098',
)
ENUM_PREFIX = 'Fact contract mismatch at '
BINDING_PREFIX = 'Missing field-level evidence for '
TERMINAL = {'success', 'partial', 'failed'}
TEMPORAL = {'lifecycle', 'effective_date', 'end_date', 'status_as_of', 'status_events'}


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class Snapshot:
    def __init__(self, root):
        self.root = Path(root).resolve(strict=True)
        self.raw = {}

    def read(self, name):
        path = self.root / name
        if path.is_symlink() or not path.is_file():
            raise ValueError(f'Missing or symlinked audited file: {path}')
        raw = path.read_bytes()
        if name in self.raw and self.raw[name] != raw:
            raise ValueError(f'Active/changing Store refused: {path}')
        self.raw[name] = raw
        return json.loads(raw)

    def verify_unchanged(self):
        for name, raw in self.raw.items():
            if (self.root / name).read_bytes() != raw:
                raise ValueError(f'Active/changing Store refused: {self.root / name}')

    def digests(self):
        return {name: sha(raw) for name, raw in sorted(self.raw.items())}


def completed_jobs(snapshot):
    result = snapshot.read('v5_continuation_result.json')
    receipt = snapshot.read('execution_completion.json')
    if receipt.get('exit_code') != 0 or receipt.get('result_sha256') != sha(snapshot.raw['v5_continuation_result.json']):
        raise ValueError('Active/unconfirmed Store refused: no matching successful post-exit receipt')
    jobs = result.get('jobs', [])
    ids = [job.get('doc_id') for job in jobs]
    if (len(ids) != len(TARGETS) or set(ids) != set(TARGETS)
            or result.get('remaining_doc_ids') != []
            or result.get('original_input_unchanged') is not True
            or any(job.get('outcome') not in TERMINAL for job in jobs)):
        raise ValueError('Active/incomplete Store refused: continuation targets are not all terminal')
    return {job['doc_id']: job for job in jobs}


def terminal_run(run, name):
    if run.get('outcome') not in TERMINAL or not run.get('finished_at'):
        raise ValueError(f'Active Store refused: nonterminal run {name}')


def evidence_spans(value, path=''):
    if isinstance(value, dict):
        if {'doc_id', 'quote', 'start', 'end'} <= value.keys():
            yield path, value
        else:
            for key, item in value.items():
                yield from evidence_spans(item, f'{path}.{key}' if path else key)
    elif isinstance(value, list):
        for index, item in enumerate(value):
            yield from evidence_spans(item, f'{path}[{index}]')


def issue_class(issue):
    if issue.startswith(ENUM_PREFIX):
        return 'enum_mismatch'
    if issue.startswith(BINDING_PREFIX):
        return 'missing_field_evidence'
    return 'other_review_issue_unclassified'


def summarize(snapshot, jobs=None):
    rules = snapshot.read('rules.json')
    sources = snapshot.read('sources.json')
    index = snapshot.read('extraction_index.json')
    latest = snapshot.read('latest_extract.json')
    terminal_run(latest, 'latest_extract.json')
    runs = {}
    run_paths = sorted((snapshot.root / 'runs').glob('*.json'))
    for path in run_paths:
        run = snapshot.read(f'runs/{path.name}')
        terminal_run(run, path.name)
        if path.stem != run.get('run_id'):
            raise ValueError(f'Run manifest identity mismatch: {path.name}')
        runs[path.stem] = run
    if jobs and latest['run_id'] not in {job['run_id'] for job in jobs.values()}:
        raise ValueError('Latest extraction is not part of the declared completed continuation')
    result = {}
    for doc_id in TARGETS:
        entry = index.get(doc_id, {})
        if jobs:
            job = jobs[doc_id]
            run = runs.get(job.get('run_id'), {})
            if (entry.get('run_id') != job.get('run_id') or run.get('outcome') != job.get('outcome')
                    or run.get('input_hashes', {}).get(doc_id) != sources.get(doc_id, {}).get('sha256')):
                raise ValueError(f'Completed target/index/run identity does not agree: {doc_id}')
            if job['outcome'] == 'success' and entry.get('status') not in {'complete', 'review'}:
                raise ValueError(f'Successful target has nonterminal index: {doc_id}')
        selected = [rule for rule in rules.values() if rule.get('source_doc_id') == doc_id]
        counts = Counter()
        lineage_findings = []
        per_rule = []
        for rule in sorted(selected, key=lambda item: item['team_rule_id']):
            ident = rule['team_rule_id']
            origin_id = rule.get('extraction_run_id')
            origin = runs.get(origin_id, {})
            config = origin.get('config', {})
            primary = sources.get(doc_id, {})
            declared = {doc_id, *config.get('supporting_doc_ids', [])}
            findings = []
            if origin.get('operation') != 'extract' or origin.get('mode') != 'live':
                findings.append('Missing live extraction origin')
            if jobs and origin_id != jobs[doc_id]['run_id']:
                findings.append('Retained rule has older/non-job extraction lineage')
            if jobs and (not str(config.get('prompt_version', '')).startswith('extract-v5-')
                         or len(config.get('fact_contract_sha256', '')) != 64):
                findings.append('Rule origin lacks v5 prompt/fact-contract digest')
            if rule.get('source_url') != primary.get('url'):
                findings.append('Rule source URL differs from retained primary source')
            if rule.get('quoted_span') not in primary.get('text', ''):
                findings.append('Primary quoted_span is absent from retained primary text')
            used = {doc_id}
            span_count = 0
            for path, span in evidence_spans(rule):
                span_count += 1
                support_id = span['doc_id']
                used.add(support_id)
                source = sources.get(support_id, {})
                text = source.get('text', '')
                if support_id not in declared:
                    findings.append(f'{path}: evidence source was not declared in extraction context: {support_id}')
                if (not isinstance(span.get('start'), int) or not isinstance(span.get('end'), int)
                        or not 0 <= span['start'] < span['end'] <= len(text)
                        or text[span['start']:span['end']] != span['quote']):
                    findings.append(f'{path}: exact quote/anchor mismatch')
                if source.get('source_type') == 'status_record':
                    if (not path.startswith('status_events[')
                            and (not span.get('supports') or set(span['supports']) - TEMPORAL)):
                        findings.append(f'{path}: status-record evidence outside explicit temporal support')
            for source_id in sorted(used):
                source = sources.get(source_id, {})
                recorded = source.get('sha256')
                if not recorded or sha(source.get('text', '').encode()) != recorded:
                    findings.append(f'{source_id}: retained source text/digest mismatch')
                if origin.get('input_hashes', {}).get(source_id) != recorded:
                    findings.append(f'{source_id}: source not pinned to origin input hash')
            issues = {kind: [] for kind in ('enum_mismatch', 'missing_field_evidence', 'other_review_issue_unclassified')}
            for issue in rule.get('review_issues', []):
                kind = issue_class(issue)
                issues[kind].append(issue)
                counts[kind + '_occurrences'] += 1
            for kind, values in issues.items():
                counts[kind + '_rules'] += bool(values)
            counts['rules'] += 1
            counts['rules_without_review_issues'] += not bool(rule.get('review_issues'))
            lineage_findings.extend({'team_rule_id': ident, 'finding': finding} for finding in sorted(set(findings)))
            per_rule.append({
                'team_rule_id': ident, 'provision_key': rule['provision_key'],
                'jurisdiction': rule['jurisdiction'], 'category': rule['category'], 'citation': rule['citation'],
                'lifecycle': rule['lifecycle'], 'effective_date': rule.get('effective_date'),
                'status_as_of': rule.get('status_as_of'), 'end_date': rule.get('end_date'),
                'extraction_run_id': origin_id, 'prompt_version': config.get('prompt_version'),
                'fact_contract_sha256': config.get('fact_contract_sha256'),
                'evidence_mode': rule.get('evidence_mode'), 'semantic_verification': rule.get('semantic_verification'),
                'source_ids': sorted(used), 'evidence_span_count': span_count, 'review_issues': issues,
            })
        result[doc_id] = {'counts': dict(sorted(counts.items())), 'index': entry,
                          'lineage_findings': lineage_findings, 'rules': per_rule}
    if sorted((snapshot.root / 'runs').glob('*.json')) != run_paths:
        raise ValueError('Active/changing Store refused: run manifest inventory changed')
    return result


def totals(documents):
    result = Counter()
    for document in documents.values():
        result.update(document['counts'])
    return dict(sorted(result.items()))


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--before', required=True, type=Path)
    parser.add_argument('--after', required=True, type=Path)
    parser.add_argument('--report', required=True, type=Path)
    args = parser.parse_args(argv)
    before, after = Snapshot(args.before), Snapshot(args.after)
    if before.root == after.root:
        raise ValueError('Before and after must be distinct stores')
    report_path = args.report.resolve()
    if any(report_path.is_relative_to(root) for root in (before.root, after.root)):
        raise ValueError('Audit report must be outside both immutable input stores')
    jobs = completed_jobs(after)  # Refuse active after-store before reading its rules/sources.
    old, new = summarize(before), summarize(after, jobs)
    comparison = {}
    for doc_id in TARGETS:
        before_counts, after_counts = old[doc_id]['counts'], new[doc_id]['counts']
        comparison[doc_id] = {'before': before_counts, 'after': after_counts,
                             'delta': {key: after_counts.get(key, 0) - before_counts.get(key, 0)
                                       for key in sorted(set(before_counts) | set(after_counts))}}
    report = {
        'label': 'READ_ONLY_EXTRACTION_V4_V5_SOFTWARE_AUDIT_NOT_LEGAL_CERTIFICATION',
        'generated_at': datetime.now(timezone.utc).isoformat(), 'script_sha256': sha(Path(__file__).read_bytes()),
        'targets': list(TARGETS), 'before_store': str(before.root), 'after_store': str(after.root),
        'limitations': [
            'Counts describe accepted persisted rules, not raw provider drafts or legal correctness.',
            'Other review issues remain verbatim and unclassified; fewer issues alone do not prove completeness.',
            'Rule counts may differ; no invented one-to-one alignment across rewritten provisions.',
            'No evaluator conclusions, factual inputs, stored rules or extraction evidence are modified.',
        ],
        'totals': {'before': totals(old), 'after': totals(new)}, 'comparison': comparison,
        'before': old, 'after': new,
        'input_file_sha256': {'before': before.digests(), 'after': after.digests()},
        'active_store_guards': ['matching root post-exit receipt', 'all six declared jobs terminal',
                                'terminal manifests and matching target index', 'unchanged bytes after audit'],
    }
    before.verify_unchanged()
    after.verify_unchanged()
    report_path.parent.mkdir(parents=True, exist_ok=True)
    with report_path.open('x', encoding='utf-8') as output:
        output.write(json.dumps(report, indent=2, ensure_ascii=False) + '\n')
    report_path.chmod(0o600)
    print(json.dumps({'report': str(report_path), 'totals': report['totals'],
                      'lineage_findings': {label: sum(len(doc['lineage_findings']) for doc in values.values())
                                           for label, values in [('before', old), ('after', new)]}}, indent=2))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except (OSError, ValueError, KeyError, TypeError) as error:
        raise SystemExit(f'Audit refused: {error}')
