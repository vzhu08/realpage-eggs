"""Regenerate and replay the recorded final package; never calls a provider."""
import argparse
from hashlib import sha256
import json
import os
from pathlib import Path
import sys
from unittest.mock import patch

sys.dont_write_bytecode = True
os.environ['PYTHON_DOTENV_DISABLED'] = '1'
os.environ['OPENAI_API_KEY'] = ''
os.environ['OPENAI_MODEL'] = ''


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', required=True, type=Path)
    parser.add_argument('--receipt', required=True, type=Path)
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output, receipt_path = args.output.resolve(), args.receipt.resolve()
    if output == receipt_path or any(p.exists() or p.is_relative_to(root) for p in (output, receipt_path)):
        raise ValueError('Choose two distinct, new outputs outside the immutable archive directory')
    from verify_archive import verify
    manifest = verify()
    sys.path.insert(0, str(root / 'runtime'))
    from navigator.evidence_package import code_version, write_evidence_package, replay_evidence_package
    from navigator.store import Store

    class ReadOnlyStore(Store):
        def write(self, *args, **kwargs):
            raise RuntimeError('The archived Store is read-only')

    if code_version().fingerprint != manifest['evidence_replay']['code_fingerprint']:
        raise ValueError('Exact replay requires the recorded Python patch version and locked dependencies')
    request = json.loads((root / 'requests/A0001.json').read_text())
    with patch('httpx.Client.send', side_effect=AssertionError('Network is forbidden during offline replay')), \
            patch('navigator.extraction.OpenAIProvider.generate', side_effect=AssertionError('Providers are forbidden during offline replay')):
        result = write_evidence_package(ReadOnlyStore(root / 'store'), request, output)
        value = json.loads(output.read_text())
        replay = replay_evidence_package(value).model_dump(mode='json')
    if replay['package_sha256'] != manifest['evidence_replay']['package_sha256']:
        raise ValueError('Rebuilt package differs from the recorded final package')
    if sha256(output.read_bytes()).hexdigest() != manifest['evidence_replay']['package_file_sha256']:
        raise ValueError('Rebuilt package bytes differ from the recorded final package')
    verify()
    receipt = {'label': manifest['label'], 'request': 'requests/A0001.json',
               'source_store': 'store/', 'runtime': 'runtime/',
               'original_receipt': 'records/final-evidence-replay-receipt.json',
               'output_file_sha256': sha256(output.read_bytes()).hexdigest(),
               'output_bytes': output.stat().st_size, 'replay': replay,
               'archive_unchanged': True, 'provider_calls': 0, 'network_calls': 0,
               'question_plan_status': value['response']['question_plan']['status'],
               'question_plan_exhaustive': value['response']['question_plan']['exhaustive']}
    receipt_path.parent.mkdir(parents=True, exist_ok=True)
    with receipt_path.open('x') as stream:
        json.dump(receipt, stream, indent=2); stream.write('\n')
    print(json.dumps({'status': replay['status'], 'package_sha256': replay['package_sha256'],
                      'question_plan_status': receipt['question_plan_status'], 'provider_calls': 0}))


if __name__ == '__main__':
    main()
