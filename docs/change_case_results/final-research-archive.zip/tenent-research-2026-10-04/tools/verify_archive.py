"""Verify all archived bytes without importing runtime code or accessing a provider."""
from hashlib import sha256
import json
from pathlib import Path


def verify():
    root = Path(__file__).resolve().parents[1]
    manifest = json.loads((root / 'MANIFEST.json').read_text())
    for name, item in manifest['files'].items():
        path = root / name
        if path.is_symlink() or not path.is_file() or not path.resolve().is_relative_to(root):
            raise ValueError(f'Missing/unsafe archive file: {name}')
        raw = path.read_bytes()
        if len(raw) != item['bytes'] or sha256(raw).hexdigest() != item['sha256']:
            raise ValueError(f'Archive file hash mismatch: {name}')
    print(json.dumps({'status': 'verified', 'files': len(manifest['files']),
                      'label': manifest['label'], 'provider_calls': 0}))
    return manifest


if __name__ == '__main__':
    verify()
